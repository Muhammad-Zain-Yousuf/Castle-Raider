#include "Treasure_Gate.hpp"

Treasure_Gate::Treasure_Gate(int x, int y) {

    x_pos = x;
    y_pos = y;

    srcRect = {193, 315, 75, 146};
    moverRect = {x, y, 58, 120};
}

void Treasure_Gate::Open() {

    if (animate == 0) { //For animating the pigeon while flying
        srcRect = {193,315,75,146}; //Change to sprite 1
        animate++; //increment counter

    } else if (animate == 1) {
        srcRect = {276,315,76,146}; //Change to sprite 2
        animate++;
    } else if (animate == 2) {
        srcRect = {364,315,76,146}; //Change to sprite 3
        animate++; //reset counter
    } else {
        srcRect = {452, 315, 75, 144};
    }
    
}