#pragma once
#include<SDL.h>

class Guard{
    // int x_pos; 
    // int y_pos;
    SDL_Rect srcRect, moverRect;
    int lim1=250;
    int lim2=500;
    int c=5;
    int animate=0; int animate1=0;

public:
    
    Guard(int x, int y); //
    void patrol();
    void draw(SDL_Renderer*, SDL_Texture* assets); //Draw function declaration
    
};