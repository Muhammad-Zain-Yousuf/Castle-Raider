#pragma once

#include "Unit.hpp"

class Decoration: public Unit {


    public:
    //Decoration(int x, int y);
    
    virtual void place() = 0;

};