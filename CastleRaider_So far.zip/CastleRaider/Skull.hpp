#include "Decoration.hpp"

class Skull: public Decoration {

    public:

        Skull(int x, int y);

        void place();
};