#include "Treasure.hpp"
#include<string>
#include<iostream>
#include<vector>

void Treasure::draw(SDL_Renderer* gRenderer, SDL_Texture* assets){
    SDL_RenderCopy(gRenderer, assets, &srcRect, &moverRect);
    //std::cout<<"Treasure has been drawn."<<std::endl;
}

void Treasure::animate_func(){

    if (animate == 0){
        while(animate != 3){
            if (animate == 0) { //For animating the treasure box to open
                    srcRect = {38,525,77,60};  //1        // or simply add its width i.e. src.x += width of chest
                } else if (animate == 1) {
                    srcRect = {378,522,77,60}; //2
                } else if (animate == 2) {
                    srcRect = {486,519,77,60}; //3
                } 
            animate++;
        }

    } else {
        while(animate != 0){
            if (animate == 3) { //For animating the treasure box to close
                    srcRect = {258,519,77,60};  //3
                } else if (animate == 2) {
                    srcRect = {150,522,77,60};  //2
                } else if (animate == 1) {
                    srcRect = {38,525,77,60};   //1
                } 
            animate--;
        }
    }
} 

void Treasure::toggle_tres(){ //Fly function for moving Treasure as tasked in manual
        
        //Debugging
        //std::cout<<"Toggle = "<<toggle<<std::endl;        

        if (toggle == 0) { //For animating the Treasure while flying
            srcRect = {486,519,77,60}; //Change to Treasure On sprite  //extra
            Treasure::animate_func();
            toggle+=1; //increment counter
        } else if (toggle == 1) {
            srcRect = {258,519,77,60}; //Change to Treasure Off sprite   //extra
            Treasure::animate_func();
            toggle=0; //reset counter
        }
    }

Treasure::Treasure(int x, int y) { //Constructor with parameters x, y for initial location of Treasure.
        // x_pos = x;
        // y_pos = y;
        srcRect = {486,519,77,60};  //Default sprite 1 -> closed treasure chest
        // Sprites co-ordinates for Filled Treasure Chest:
        // Treasurechest_1 srcRect = {38,525,77,60};    -> closed treasure chest 
        // Treasurechest_2 srcRect = {378,522,77,60};   -> partially opened treasure chest 
        // Treasurechest_3 srcRect = {486,519,77,60};   -> opened treasure chest

        // Sprites co-ordinates for Empty Treasure Chest:
        // Treasurechest_1 srcRect = {38,525,77,60};    -> closed treasure chest 
        // Treasurechest_2 srcRect = {150,522,77,60};   -> partially opened treasure chest 
        // Treasurechest_3 srcRect = {258,519,77,60};   -> opened treasure chest
        moverRect = {x, y, 60, 45}; //set Treasure at x_pos, y_pos on screen with size 50, 60
    }