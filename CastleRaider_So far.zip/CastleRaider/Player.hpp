#pragma once
#include "Unit.hpp"

class Player: public Unit {
   
    int mov_up=0;
    int mov_down=0;
    int mov_left=0;
    int mov_right=0;

public:
    
    Player(int, int); //Default values set for creation of Treasure at bottom left corner, only kept for debugging purposes.

    void move_up();
    void move_down();
    void move_left();
    void move_right();

    
};