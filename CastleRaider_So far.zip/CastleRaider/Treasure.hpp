#pragma once
#include<SDL.h>

class Treasure{
    // int x_pos; //Variables for Treasure position
    // int y_pos;
    SDL_Rect srcRect, moverRect;
    int toggle = 0; // Variable for keeping track and changing of Treasure sprite as it flies.
    int animate = 0; // Variable for the anmation of opening/closing the treasure chest.

public:
    //Constructor with parameters x, y for initial location of Treasure.
    Treasure(int, int); //Default values set for creation of Treasure at bottom left corner, only kept for debugging purposes.

    void toggle_tres();
    // void animate_func(int i, int j);
    void animate_func();

    void draw(SDL_Renderer*, SDL_Texture* assets); //Draw function declaration
    
};
