#pragma once
#include<SDL.h>

class Treasure_key{
    // int x_pos; //Variables for Treasure_key position
    // int y_pos;
    SDL_Rect srcRect, moverRect;
    int toggle = 0; //Variable for keeping track and changing of Treasure_key sprite as it flies.

public:
    //Constructor with parameters x, y for initial location of Treasure_key.
    // Treasure_key(int x = 206, int y = 451); //Default values set for creation of Treasure_key at bottom left corner, only kept for debugging purposes.
    Treasure_key(int, int);

    void hide_toggle(); 

    void draw(SDL_Renderer*, SDL_Texture* assets); //Draw function declaration
    
};

