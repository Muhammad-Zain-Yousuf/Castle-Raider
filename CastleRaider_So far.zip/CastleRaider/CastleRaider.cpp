#include "CastleRaider.hpp"
#include<iostream>
#include<list>
#include<algorithm>
#include<iterator>

void CastleRaider::drawObjects(){
    S_vec[0].draw(gRenderer, assets);
    S_vec[0].toggle_tiles();
    G_vec[0].draw(gRenderer, assets);
    K_vec[0].draw(gRenderer, assets);
    T_vec[0].draw(gRenderer, assets);

    Tg_vec[0].draw(gRenderer, assets);
    Tg_vec[0].Open();
    G_vec[0].draw(gRenderer, assets);
    lev[0].draw(gRenderer, assets);
    lev[0].rotate();

    P_vec[0].draw(gRenderer, assets);

    for (std::list<Fire*>::iterator fire=F_list.begin(); fire != F_list.end(); fire++) { 
        (*(fire))->draw(gRenderer, assets);
        (*(fire))->place();
    }
    
    for (std::list<Skull*>::iterator sk=S_list.begin(); sk != S_list.end(); sk++) { 
        (*(sk))->draw(gRenderer, assets);
        (*(sk))->place();
    }

    for (std::list<Pots*>::iterator pot=P_list.begin(); pot != P_list.end(); pot++) { 
        (*(pot))->draw(gRenderer, assets);
        (*(pot))->place();
    }

    for (std::list<Drums*>::iterator drum=D_list.begin(); drum != D_list.end(); drum++) { 
        (*(drum))->draw(gRenderer, assets);
        (*(drum))->place();
    }


}

void CastleRaider::createObject(){
    Spikes S1(175,480);   
    S_vec.push_back(S1);        
    Treasure_key K1(190,440);
    K_vec.push_back(K1); 
    Treasure T1(780,195);
    T_vec.push_back(T1); 
    Lever L1(360, 170);
    lev.push_back(L1);

    Player P1(740,490);
    P_vec.push_back(P1);

    Treasure_Gate TG1(883,270);
    Tg_vec.push_back(TG1);
    Main_Gate G1(470, 40);  
    G_vec.push_back(G1);
    
    for(int i = 0; i < 2; i++) {

        if (i == 0) {
            S_list.push_back(new Skull(75, 200));
            D_list.push_back(new Drums(880, 470, '1'));
            F_list.push_back(new Fire(200, 100));
            P_list.push_back(new Pots(70, 440,'1'));

        }

        else
        {
            S_list.push_back(new Skull(880, 200));
            D_list.push_back(new Drums(820, 400, '3'));
            D_list.push_back(new Drums(610, 150, '2'));
            F_list.push_back(new Fire(880, 100));
            F_list.push_back(new Fire(200, 330));
            P_list.push_back(new Pots(110, 420,'2'));
        }
        
    }
                 
   
}

void CastleRaider::Hero(string direction) {

    
    if (direction == "up") P_vec[0].move_up();

    else if (direction == "down") P_vec[0].move_down();

    else if (direction == "right") P_vec[0].move_right();

    else if (direction == "left") P_vec[0].move_left();

}


CastleRaider::CastleRaider(SDL_Renderer *renderer, SDL_Texture *asst):gRenderer(renderer), assets(asst){}

CastleRaider::~CastleRaider() {

    for (std::list<Fire*>::iterator fire=F_list.begin(); fire != F_list.end(); fire++) { 
        delete (*(fire));
        (*(fire)) = NULL;
    }

    F_list.clear();
    
    for (std::list<Skull*>::iterator sk=S_list.begin(); sk != S_list.end(); sk++) { 
        delete (*(sk));
        (*(sk)) = NULL;
    }

    S_list.clear();

    for (std::list<Pots*>::iterator pot=P_list.begin(); pot != P_list.end(); pot++) { 
        delete (*(pot));
        (*(pot)) = NULL;
    }

    P_list.clear();

    for (std::list<Drums*>::iterator drum=D_list.begin(); drum != D_list.end(); drum++) { 
        delete (*(drum));
        (*(drum)) = NULL;
    }

    D_list.clear();   

}