#include "Player.hpp"
#include<string>
#include<iostream>


// int mov_up;
// int mov_down;
// int mov_left;
// int mov_right;

void Player::move_up(){
        if (mov_up == 0) { 
            srcRect = {421,889,85,90};
            mov_up+=1; //increment counter
        } else if (mov_up == 1) {
            srcRect = {329,891,86,88};  
            mov_up+=1; //increment counter
        } else if (mov_up == 2) {
            srcRect = {511,891,87,88}; 
            mov_up=0; //reset counter
        }
    moverRect.y-=20;
}
void Player::move_down(){
        if (mov_down == 0) { 
            srcRect = {421,602,85,91};
            mov_down+=1; //increment counter
        } else if (mov_down == 1) {
            srcRect = {330,604,85,89};  
            mov_down+=1; //increment counter
        } else if (mov_down == 2) {
            srcRect = {511,604,85,89}; 
            mov_down=0; //reset counter
        }
        moverRect.y+=20;
}
void Player::move_left(){
        if (mov_left == 0) { 
            srcRect = {427,697,70,90};
            mov_left+=1; //increment counter
        } else if (mov_left == 1) {
            srcRect = {336,697,71,90};  
            mov_left+=1; //increment counter
        } else if (mov_left == 2) {
            srcRect = {517,697,71,90}; 
            mov_left=0; //reset counter
        }
         moverRect.x-=20;
}
void Player::move_right(){
        if (mov_right == 0) { 
            srcRect = {427,791,70,93};
            mov_right+=1; //increment counter
        } else if (mov_right == 1) {
            srcRect = {336,792,71,92};  
            mov_right+=1; //increment counter
        } else if (mov_right == 2) {
            srcRect = {517,791,71,93}; 
            mov_right=0; //reset counter
        }
         moverRect.x+=20;
}


Player::Player(int x, int y) { //Constructor with parameters x, y for initial location of Player

    x_pos = x;
    y_pos = y;
    srcRect = {421,889,85,90};  //Default sprite 1 -> set as off by default
    moverRect = {x, y, 50, 50}; //set Player at x_pos, y_pos on screen with size 40,40
    }