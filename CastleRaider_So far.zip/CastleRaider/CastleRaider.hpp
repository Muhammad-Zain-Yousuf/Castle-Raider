#pragma once
#include<SDL.h>
#include "Spikes.hpp"
#include "Treasure_key.hpp"
#include "Treasure.hpp"
#include "fire.hpp"
#include "Main_Gate.hpp"
#include "Treasure_Gate.hpp"
#include "Skull.hpp"
#include "Pots.hpp"
#include "Drums.hpp"
#include "Lever.hpp"
#include "Player.hpp"
#include <string>
#include <vector>
#include <list>

using namespace std;

class CastleRaider{
    SDL_Renderer *gRenderer;
    SDL_Texture *assets;

    // int p = 0; int eg= 0; int Ne = 0;       // Counters initialized to count number of objects that need to be drawn on the screen.
    vector <Spikes> S_vec;                  // we create three vectors for the objects that are present in our game. (bird, nest, pigeon)
    vector <Treasure_key> K_vec;                     
    vector <Treasure> T_vec;
    vector <Treasure_Gate> Tg_vec;
    vector <Main_Gate> G_vec;
    vector <Lever> lev;
    vector <Player> P_vec;
    
    list <Fire*> F_list;
    list <Skull*> S_list;
    list <Drums*> D_list;
    list <Pots*> P_list;

    public:
    CastleRaider(SDL_Renderer *, SDL_Texture *);
    void drawObjects(); 
    void createObject();
    void Hero(string direction);
    ~CastleRaider();
};