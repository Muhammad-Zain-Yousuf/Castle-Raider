#include "Unit.hpp"

class Lever: public Unit {

    int animate = 0;

    public:

        Lever(int x, int y);

        void rotate();
};