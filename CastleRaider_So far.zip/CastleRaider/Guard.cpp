#include "Guard.hpp"
#include<string>
#include<iostream>

void Guard::draw(SDL_Renderer* gRenderer, SDL_Texture* assets){
    SDL_RenderCopy(gRenderer, assets, &srcRect, &moverRect);
    //std::cout<<"Treasure has been drawn."<<std::endl;
}


void Guard::patrol(){
    if (c==lim1)
    {
        srcRect = {427,697,70,90};
        // c-=5 //turning
        
    }

    if (c==lim2)
    {
        srcRect = {427,697,70,90};  //turning
        // c-=5

    }

    else if (c<lim1)
    {   
        if (c==5){
            srcRect = {421,889,85,90};
            
        }
        else if (animate == 0) { 
            srcRect = {421,889,85,90};
            animate+=1;      //increment counter
        } else if (animate == 1) {
            srcRect = {329,891,86,88};   
            animate+=1;       //increment counter
        } else if (animate == 2) {
            srcRect = {511,891,87,88};
            animate=0;      //reset counter
        }
        moverRect.y-=5;
       
    }
    else if (c<lim2)
    {
        if (c==lim1){
            srcRect = {421,602,85,91};
        }
        else if (animate1 == 0) { 
            srcRect = {421,602,85,91};
            animate1+=1; //increment counter
        } else if (animate1 == 1) {
            srcRect = {330,604,85,89};  
            animate1+=1; //increment counter
        } else if (animate1 == 2) {
            srcRect = {511,604,85,89}; 
            animate1=0; //reset counter
        }
        moverRect.y+=5;
    }
    else
    {
        c=0;
    }

    
    c+=5;

        
    

}






// 404, 466



Guard::Guard(int x, int y) { //Constructor with parameters x, y for initial location of Player
        srcRect = {35,887,89,92};  //Default sprite 1 -> set as off by default
        moverRect = {x, y, 50, 50}; //set Player at x_pos, y_pos on screen with size 40,40
    }