#pragma once
#include<SDL.h>

class Spikes{
    // int x_pos; //Variables for Spikes position
    // int y_pos;
    SDL_Rect srcRect, moverRect;
    int toggle = 0; //Variable for keeping track and changing of Spikes sprite as it flies.

public:
    void toggle_tiles(); 
    void draw(SDL_Renderer*, SDL_Texture* assets); //Draw function declaration
    Spikes(int, int); //Default values set for creation of Spikes at bottom left corner, only kept for debugging purposes.
};
