#include "Spikes.hpp"
#include<string>
#include<iostream>
#include<vector>

void Spikes::draw(SDL_Renderer* gRenderer, SDL_Texture* assets){
    SDL_RenderCopy(gRenderer, assets, &srcRect, &moverRect);
    //std::cout<<"Spikes has been drawn."<<std::endl;
}


void Spikes::toggle_tiles(){ //Fly function for moving Spikes as tasked in manual
        
        //Debugging
        //std::cout<<"Toggle = "<<toggle<<std::endl;        

        if (toggle == 0) { //For animating the Spikes while flying
            srcRect = {997,133,76,78}; //Change to Spikes On sprite 
            toggle+=1; //increment counter
        } else if (toggle == 1) {
            srcRect = {1087,134,76,78}; //Change to Spikes Off sprite 
            toggle=0; //reset counter
        }
    }


Spikes::Spikes(int x, int y) { //Constructor with parameters x, y for initial location of Spikes.
        // x_pos = x;
        // y_pos = y;
        srcRect = {1087,134,76,78};  //Default sprite 1 -> set as off by default
        // Sprites co-ordinates for Spikess
        // SpikesOn srcRect = {997,133,1075,212};
        // SpikesOff srcRect = {1087,134,1163,212};
        moverRect = {x, y, 60, 60}; //set Spikes at x_pos, y_pos on screen with size 50,60
    }