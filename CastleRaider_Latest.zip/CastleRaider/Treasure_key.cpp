#include "Treasure_key.hpp"
#include<string>
#include<iostream>
#include<vector>

void Treasure_key::draw(SDL_Renderer* gRenderer, SDL_Texture* assets){
    SDL_RenderCopy(gRenderer, assets, &srcRect, &moverRect);
    //std::cout<<"Treasure_key has been drawn."<<std::endl;
}


void Treasure_key::hide_toggle(){ //Fly function for moving Treasure_key as tasked in manual
        
        //Debugging
        //std::cout<<"Toggle = "<<toggle<<std::endl;        

        if (toggle == 0) { 
            srcRect = {427,244,43,42}; //Change to Treasure_key On sprite 
            toggle+=1;
        } else if (toggle == 1) {
            srcRect = {476,245,43,42}; //Change to Treasure_key Off sprite 
            toggle=0; //reset counter
        }
    }



Treasure_key::Treasure_key(int x, int y) { //Constructor with parameters x, y for initial location of Treasure_key.
        // x_pos = x;
        // y_pos = y;
        srcRect = {427,244,43,42};  //Default sprite 1 -> golden key
        //Sprites co-ordinates for Treasure_keys
        // Treasure_keyShow srcRect = {427,244,43,42};
        // Treasure_keyHide srcRect = {476,245,43,42};
        moverRect = {x, y, 30, 30}; //set Treasure_key at x_pos, y_pos on screen with size 50,60
    }
